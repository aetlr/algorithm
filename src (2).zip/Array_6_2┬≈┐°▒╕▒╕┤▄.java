public class Array_6_2차원구구단 {
    public static void main(String[] args) {
        int[][] arr = new int[10][10];
        for (int i = 2; i < 10; i++, System.out.println()) {
            System.out.println(" " + i + "단");
            for (int j = 0; j < 10; j++) {
                arr[i][j] = i * j;
                System.out.println(i + " * " + j + " = " + arr[i][j]);
            }

        }
    }
}
