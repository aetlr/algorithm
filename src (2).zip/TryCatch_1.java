import javax.swing.*;

public class TryCatch_1 {
    public static void main(String[] args) {
        int a = 100;
        int b = 0;
        int c = a / b;
        JOptionPane.showMessageDialog(null, c);
    }
}
