public class Array_1 {
    public static void main(String[] args) {
        int Home[] = new int[5];
        for (int i = 0; i < Home.length; i++) {
            Home[i] = i;
            System.out.println(Home[i] + "방");
        }
    }
}
