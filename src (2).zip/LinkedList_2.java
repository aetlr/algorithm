import java.util.Arrays;
import java.util.LinkedList;

public class LinkedList_2 {
    public static void main(String[] args) {
        LinkedList<String> colors = new LinkedList<>(Arrays.asList("Black,White,Green,Red".split(",")));

        boolean ox = colors.contains("Black");
        System.out.println(ox);

        int index = colors.indexOf("Blue");
        System.out.println(index);

        index = colors.indexOf("Red");
        System.out.println(index);
    }
}
