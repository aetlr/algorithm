import java.util.Arrays;

public class Array_3_sort{
    public static void main(String[] args) {
        Integer num[] = {2, 22, 1, 13, -11};
        Arrays.sort(num);

        for (int n : num) {
            System.out.print(n + "\t");
        }
    }
}
