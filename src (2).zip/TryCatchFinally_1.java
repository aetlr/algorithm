import javax.swing.*;

public class TryCatchFinally_1 {
    public static void main(String[] args) {
        int Array[] = {1, 2, 3};
        try {
            int s1 = Integer.parseInt(JOptionPane.showInputDialog(null, "100을 나눌 수 입력"));
            int result = 100 / s1;
            JOptionPane.showMessageDialog(null, result);

            int s2 = Integer.parseInt(JOptionPane.showInputDialog(null, "배열조회 번호 입력"));
            int element = Array[s2];
            JOptionPane.showMessageDialog(null, element);
        } catch (ArithmeticException e) {
            System.out.println(e.toString());
            System.out.println("0으로 나누었습니다");
        } catch (ArrayIndexOutOfBoundsException e) {
            System.out.println(e.toString());
            System.out.println("배열의 개수를 초과하였습니다");
        } finally {
            System.out.println("프로그램을 종료합니다");
        }
    }
}
