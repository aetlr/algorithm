import javax.swing.*;

public class Array_2_sum {
    public static void main(String[] args) {
        int[] arr = {100, 85, 95, 45, 75, 88, 65, 78, 75, 83};
        int sum = 0;

        for (int i = 0; i < arr.length; i++) {
            sum += arr[i];
        }

        JOptionPane.showMessageDialog(null, "총점: " + sum);
    }
}
