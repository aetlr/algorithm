import javax.swing.*;

public class TryCatch_2 {
    public static void main(String[] args) {
        int a = JOptionPane.showConfirmDialog(null, "나누어지는 수를 입력하세요");
        int b = JOptionPane.showConfirmDialog(null, "나누는 수를 입력하세요");
        try {
            int c = a / b;
            JOptionPane.showMessageDialog(null, c);
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}
