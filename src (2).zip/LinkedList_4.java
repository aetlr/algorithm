import java.util.Arrays;
import java.util.LinkedList;
import java.util.Iterator;
import java.util.ListIterator;

public class LinkedList_4 {
    public static void main(String[] args) {
        LinkedList<String> colors = new LinkedList<>(Arrays.asList("Black", "White", "Green", "Red"));

        for (String color : colors) {
            System.out.print(color + " ");
        }
        System.out.println();

        for (int i = 0; i < colors.size(); ++i) {
            System.out.print(colors.get(i) + " ");
        }
        System.out.println();

        Iterator<String> iterator = colors.iterator();
        while (iterator.hasNext()) {
            System.out.print(iterator.next() + " ");
        }
        System.out.println();

        ListIterator<String> listIterator = colors.listIterator(colors.size());
        while (listIterator.hasPrevious()) {
            System.out.print(listIterator.previous() + " ");
        }
        System.out.println();
    }
}
