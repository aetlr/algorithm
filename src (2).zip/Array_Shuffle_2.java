import java.util.Arrays;
import java.util.Collections;

public class Array_Shuffle_2 {
    public static void main(String[] args) {
        String[] arr = new String[10];
        for (int i = 0; i < arr.length; i++) {
            arr[i] = Integer.toString(i);
        }
        Collections.shuffle(Arrays.asList(arr));
        for (int i = 0; i < arr.length; i++) {
            System.out.print(arr[i] + "\t");
        }
    }
}
