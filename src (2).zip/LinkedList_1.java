import java.util.LinkedList;

public class LinkedList_1 {
    public static void main(String[] args) {
        LinkedList<String> colors = new LinkedList<>();

        colors.add("Black");
        colors.add("White");
        colors.add(0, "Green");
        colors.add("Red");

        colors.set(0, "Blue");
        System.out.println(colors);

        colors.removeFirst();
        colors.removeLast();

        System.out.println(colors);
    }
}
