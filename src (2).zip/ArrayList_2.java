import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.ListIterator;

class ArrayList_3 {
    public static void main(String[] args) {
        ArrayList<String> list1 = new ArrayList<>();
        List<Integer> list2 = Arrays.asList(1, 2, 3);
        List<String> list3 = Arrays.asList("대한", "민국", "만세");

        list1.add("홍길동");
        list1.add("이순신");
        list1.add("유관순");
        list1.add("강감찬");

        list1.set(2, "백설공주");
        list1.remove(1);

        list1.set(1, "가나다");

        for (String string : list1) {
            System.out.println(string);
        }

        for (int val : list2) {
            System.out.println(val);
        }

        for (String string : list3) {
            System.out.println(string);
        }

        ListIterator<String> listit = list3.listIterator(list3.size());
        for (String string : list3) {
            System.out.println(listit.previous() + " ");
        }
    }
}
