import java.time.LocalTime;

public class date_7 {

    public static void main(String[] args) {
        LocalTime time = LocalTime.now();
        System.out.println(time);

        LocalTime endTime = LocalTime.of(23, 59, 59);
        System.out.println(endTime);

        System.out.println(time.isBefore(endTime));

        System.out.println(time.isAfter(endTime));

    }
}
