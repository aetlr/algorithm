import java.text.SimpleDateFormat;
import java.util.Date;

public class date_1 {
    public static void main(String[] args) {
        Date date = new Date();
        System.out.println(date); // 기본 형태

        //formatter로 출력형식 변경
        SimpleDateFormat newDate = new SimpleDateFormat("오늘은 yyy년 MM월 dd일(E) 입니다");
        System.out.println(newDate.format(date));
    }
}
