import java.time.LocalDateTime;

public class date_6 {
    public static void main(String[] args) {
        LocalDateTime startDateTime = LocalDateTime.now();
        // 현재: 년-월-일T시:분:나노초
        System.out.println(startDateTime);

        LocalDateTime endDateTime = LocalDateTime.of(2023, 12, 31, 0, 0, 0);
        System.out.println(endDateTime);

        System.out.println(startDateTime.isBefore(endDateTime));
        // startDateTime이 endDateTime보다 이전인지 확인


        System.out.println(startDateTime.isEqual(endDateTime));
        // startDateTime과 endDateTime이 같은지 확인

        System.out.println(startDateTime.isAfter(endDateTime));
        // startDateTime이 endDateTime보다 이후인지 확인
    }
}
