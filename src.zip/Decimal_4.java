import java.math.BigDecimal;
import java.math.RoundingMode;
import java.text.DecimalFormat;

public class Decimal_4 {
    public static void main(String[] args) {
        double rnd = 112399.405;
        DecimalFormat df = new DecimalFormat("#,###.00");
        System.out.println(df.format(rnd));

        df.setRoundingMode(RoundingMode.HALF_UP);
        BigDecimal bd = BigDecimal.valueOf(rnd);
        System.out.println(df.format(bd));
    }
}
