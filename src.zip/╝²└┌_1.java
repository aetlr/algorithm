import java.text.NumberFormat;

public class 숫자_1 {
    public static void main(String[] args) {
        int quantity = 5;
        double unitPrice = 5000;
        double taxRate = 0.1;
        double totalCost;
        double subTotal, tax;

        subTotal = quantity * unitPrice;
        tax = subTotal * taxRate;
        totalCost = subTotal + tax;

        NumberFormat fmt1 = NumberFormat.getCurrencyInstance();
        NumberFormat fmt2 = NumberFormat.getPercentInstance();

        System.out.println("세전 구입 금액: " + fmt1.format(subTotal));
        System.out.println("부가세: " + fmt1.format(tax) + " (" + fmt2.format(taxRate) + ")");
        System.out.println("총금액: " + fmt1.format(totalCost));
    }
}
