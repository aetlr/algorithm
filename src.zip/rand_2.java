import java.util.Random;

public class rand_2 {
    public static void main(String[] args) {
        System.out.println(Math.random());

        Random r = new Random();
        for (int i = 0; i < 10; i++) {
            System.out.print(r.nextInt(100) + "\t");
        }
    }
}
