public class rand3 {
    public static void main(String[] args) {
        System.out.println(Math.random());

        for (int i = 0; i < 10; i++) {
            System.out.print(Integer.valueOf((int) (Math.random() * 100) + 1) + "\t");
        }
    }
}
