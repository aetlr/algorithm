import java.util.StringTokenizer;

public class Str_token {
    public static void main(String[] args) {
        //특정 기준으로 분리하기(토큰)
        String tel = "010-1111-2222";

        StringTokenizer token = new StringTokenizer(tel, "-");

        while (token.hasMoreTokens()) {
            System.out.println(token.nextToken());
        }
    }
}
