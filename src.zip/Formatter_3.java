import javax.swing.text.MaskFormatter;
import java.text.ParseException;

public class Formatter_3 {
    public static void main(String[] args) throws ParseException {
        MaskFormatter formatter = new MaskFormatter("(###) ###-####");
        String[] phone = {"01111112222", "01122223333", "01133332222"};
        formatter.setValueContainsLiteralCharacters(false);

        for (String p : phone) {
            System.out.println(formatter.valueToString(p));
        }

    }
}
