public class Str_split {
    public static void main(String[] args) {
        String tel = "010-1111-2222";

        String[] str = tel.split("-"); // -로 분리한 것을 배열로
        for (int i = 0; i < str.length; i++) {
            System.out.println(str[i]);
        }
    }
}
