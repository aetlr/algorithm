import javax.swing.*;
import java.time.LocalDate;

public class date_4 {
    LocalDate now = LocalDate.now();

    public static void main(String[] args) {
        new date_4();
    }

    public Integer ints(String str) {
        return Integer.parseInt(str);
    }

    public date_4() {
        String input = JOptionPane.showInputDialog("주민번호를 999999-9999999 형식으로 입력하세요");
        String year = (ints(input.substring(7, 8)) >= 3) ? "20" : "19";
        // 3보다 크거나 같으면 2000년대, 아니면 1900년대

        String month = input.substring(2, 4); // 앞 2글자
        String day = input.substring(4, 6); // 2~4번째 글자

        LocalDate user = LocalDate.of(
                ints(year),
                ints(month),
                ints(day)
        );

        int a = now.minusYears(user.getYear()).getYear(); // 만나이
        if (user.plusYears(a).isAfter(now)) {
            a -= 1;
        }
        JOptionPane.showMessageDialog(null, a + "살");
    }

}

