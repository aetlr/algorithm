public class parse_1 {
    public static void main(String[] args) {
        String a = "100";
        String b = "200";
        String c;
        int d = Integer.parseInt(a) + Integer.parseInt(b);
        // 문자를 숫자로 변환

        c = a + b; // 문자 형태로 더함(합침)
        System.out.println(c); // 문자
        System.out.println(d); // 숫자
    }
}
