import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Calendar;

public class date_3 {
    public static void main(String[] args) {
        Calendar cal = Calendar.getInstance();
        Calendar cal1 = Calendar.getInstance();
        Calendar cal2 = Calendar.getInstance();
        Calendar cal3 = Calendar.getInstance();

        DateFormat newDate = new SimpleDateFormat(
                "지금은 yyyy년 MM월 dd일 aa hh시 mm분 ss초 입니다"
        );
        System.out.println(newDate.format(cal.getTime()));

        cal1.add(Calendar.MONTH, 1);
        DateFormat newDate1 = new SimpleDateFormat(
                "지금부터 1개월 후 yyyy년 MM월 dd일 aa hh시 mm분 ss초 입니다"
        );
        System.out.println(newDate1.format(cal1.getTime()));

        cal2.add(Calendar.YEAR, -1);
        DateFormat newDate2 = new SimpleDateFormat(
                "지금부터 1년 전 yyyy년 MM월 dd일 aa hh시 mm분 ss초 입니다"
        );

        System.out.println(newDate2.format(cal2.getTime()));

        cal3.add(Calendar.DATE, 100);
        DateFormat newDate3 = new SimpleDateFormat(
                "지금부터 100일 후 yyyy년 MM월 dd일 aa hh시 mm분 ss초 입니다"
        );
        System.out.println(newDate3.format(cal3.getTime()));

    }
}
