public class math_1 {
    public static void main(String[] args) {
        System.out.println("1. Math.pow(제곱근): " + Math.pow(5, 2));
        System.out.println("2. Math.sqrt(루트): " + Math.sqrt(25));
        System.out.println("3. Math.log10(상용로그): " + Math.log10(10));
        System.out.println("4. Math.sin(싸인): " + Math.sin(60));
        System.out.println("5. Math.abs(절댓값): " + Math.abs(-123));
        System.out.println("6. Math.max(큰값): " + Math.max(5, 2));
        System.out.println("7. Math.PI: " + Math.PI);
        System.out.println("8. Math.round(반올림): " + Math.round(1234.567));
        System.out.println("9. Math.floor(버림): " + Math.floor(1234.567));
        System.out.println("10. Math.ceil(올림): " + Math.ceil(1234.567));
        System.out.printf("11. 소수 둘째자리에서 반올림: %.2f\n", 1234.567);


    }
}
