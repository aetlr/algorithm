import java.text.DecimalFormat;

public class Decimal_1 {
    public static void main(String[] args) {
        int price = 1000000;
        DecimalFormat dl = new DecimalFormat("#,##0원");
        System.out.println(dl.format(price));
    }
}
