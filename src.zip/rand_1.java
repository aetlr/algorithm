public class rand_1 {
    public static void main(String[] args) {
        //0~1 사이의 무작위 난수

        for (int i = 0; i < 10; i++) {
            //1~100 사이의 정수 10개 출력
            System.out.println((int)(Math.random() * 100) + 1);

        }
    }
}
