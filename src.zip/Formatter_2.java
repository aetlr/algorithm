import javax.swing.text.MaskFormatter;
import java.text.ParseException;

public class Formatter_2 {
    public static void main(String[] args) throws ParseException {
        MaskFormatter ft = new MaskFormatter("###-###");
        ft.setValueContainsLiteralCharacters(false);
        System.out.println(ft.valueToString("123456"));
    }
}
