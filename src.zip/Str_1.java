public class Str_1 {
    public static void main(String[] args) {
        String str = "java programming";
        System.out.println(str.charAt(5)); // 0부터 시작
        System.out.println(str.substring(5)); // 5번째부터 끝까지\
        System.out.println(str.substring(0, 4)); // 0부터 4번째까지
    }
}
