public class pattern_1 {
    public static void main(String[] args) {
        String pattern = "^[0-9]*$";
        String val = "123456789";

        boolean regex = val.matches(pattern);
        System.out.println(regex);
    }
}
