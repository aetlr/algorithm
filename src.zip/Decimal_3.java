import java.text.DecimalFormat;
import java.text.ParseException;

public class Decimal_3 {
    public static void main(String[] args) throws ParseException {
        DecimalFormat df = new DecimalFormat();
        Number num = df.parse("123.345.78");
        System.out.println(num.doubleValue());
    }
}
