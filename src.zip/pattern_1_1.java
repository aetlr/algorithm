import javax.swing.*;

public class pattern_1_1 {
    public static void main(String[] args) {
        String pattern = "^[0-9]*$";
        String val = JOptionPane.showInputDialog("숫자 입력");

        boolean regex = val.matches(pattern);
        if (regex) {
            JOptionPane.showMessageDialog(null, "숫자입니다.");
        } else {
            JOptionPane.showMessageDialog(null, "숫자가 아닙니다.");
        }
    }
}
