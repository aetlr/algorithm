public class str_2 {
    public static void main(String[] args) {
        StringBuilder sb = new StringBuilder();
        sb.append("java");
        sb.append("programming");
        System.out.println("결과: " + sb); // 연결

        //sb 중간에 문자 " " 추가
        sb.insert(4, " ");
        System.out.println("결과: " + sb);

        // 1글자 변경
        sb.setCharAt(0, 'i');
        System.out.println("결과: " + sb);

        //문자열 변경
        sb.replace(5, 100, "프로그래밍"); // 5부터 100~까지 변경
        System.out.println("결과: " + sb);

        //삭제
        sb.delete(5, 100);
        System.out.println("결과: " + sb);
    }
}
