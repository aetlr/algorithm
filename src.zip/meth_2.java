public class meth_2 {
    public static void main(String[] args) {
        System.out.println("메소드 시작");
        methdCall(12);
        methdCall(30);
        System.out.println("메소드 끝");
    }

    private static void methdCall(int i ) {
        System.out.print("나의 나이는 ");
        System.out.println(i + " 세 입니다.");
    }
}
