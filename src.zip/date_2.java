import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Calendar;

public class date_2 {
    public static void main(String[] args) {
        Calendar cal = Calendar.getInstance();
        DateFormat newDate = new SimpleDateFormat(
                "지금은 yyyy년 MM월 dd일 aa hh시 mm분 ss초 입니다"
        );
        System.out.println(newDate.format(cal.getTime()));
    }
}
