import java.time.LocalDate;
import java.time.Period;
import java.time.temporal.ChronoUnit;

public class date_8 {
    public static void main(String[] args) {
        LocalDate startDate = LocalDate.of(2023, 11, 30);
        LocalDate endDate = LocalDate.of(2023, 12, 31);

        Period period = Period.between(startDate, endDate);

        System.out.println(period.getYears());
        System.out.println(period.getMonths());
        System.out.println(period.getDays());

        System.out.println(ChronoUnit.DAYS.between(startDate, endDate));
    }
}
