import javax.swing.text.MaskFormatter;
import java.text.ParseException;

public class Formatter_1 {
    public static void main(String[] args) throws ParseException {
        MaskFormatter ft = new MaskFormatter("###");
        System.out.println(ft.valueToString("1"));
        System.out.println(ft.valueToString("12"));
        System.out.println(ft.valueToString("123"));
        System.out.println(ft.valueToString("1234"));
        System.out.println(ft.valueToString("12345"));

    }
}
