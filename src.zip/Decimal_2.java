import java.text.DecimalFormat;

public class Decimal_2 {
    public static void main(String[] args) {
        double price = 1234.567;
        DecimalFormat number1 = new DecimalFormat("0.000.#####원");
        DecimalFormat number2 = new DecimalFormat("0.000.00000원");

        DecimalFormat number3 = new DecimalFormat("0.000.##원");
        DecimalFormat number4 = new DecimalFormat("0.000.00원");

        System.out.println(number1.format(price));
        System.out.println(number2.format(price));
        System.out.println(number3.format(price));
        System.out.println(number4.format(price));

    }
}
