/** @type {import('tailwindcss').Config} */
module.exports = {
  content: ["html/*.html"],
  theme: {
    extend: {},
  },
  plugins: [],
}

